import java.util.ArrayList;
import java.util.Scanner;

public class StudentTestClass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int x;

        System.out.println("How many students do you want to add?");
        x = scanner.nextInt();
        Student[] students = new Student[x];
        for (int i = 0; i < students.length; i++) {
            students[i] = new Student();
            students[i].pick();
            students[i].displayBalance();
            students[i].tuitionPayment();
            students[i].showInfo();
        }
    }
}
