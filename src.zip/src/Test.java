import java.lang.reflect.Array;

public class Test {
    public static void main(String[] args) {
        Demo newArrays = new Demo(3);
        newArrays.insert(10);
        newArrays.insert(20);
        newArrays.insert(30);
        newArrays.insert(40);
        newArrays.insert(50);
        newArrays.deleteAtIndex(4);
        System.out.println(newArrays.search(40));


    }
}

class Demo {
    private int[] items;
    private int count;

    public Demo(int length) {
        items = new int[length];
    }

    public void show() {
        for (int i = 0; i < count; i++) {
            System.out.println(items[i]);
        }
    }

    public void insert(int number) {

        if (items.length == count) {
            int[] newItem = new int[count * 2];
            for (int i = 0; i < count; i++) {
                newItem[i] = items[i];
            }
            items = newItem;

        }

        items[count++] = number;
    }

    public void deleteAtIndex(int index) {
        if (index < 0 || index >= count) {
            throw new IllegalArgumentException();
        }
        for (int i = index; i < count; i++) {
            items[i] = items[i + 1];

        }
        count--;
    }

    public int search(int number) {
        for (int i = 0; i < count; i++) {
            if (items[i] == number) {
                return i;
            }
        }
        return -1;
    }
}


