import java.text.ParseException;
import java.util.Scanner;

public class Student {
    private String name;
    private String lastName;
    private int gradeYear;
    private String courses = "";
    private int studentBills;
    private int studentBalance = 0;
    private String studentID;
    private static int id = 100;
    private int costOfCourse = 600;
    static Scanner scanner = new Scanner(System.in);

    public Student() {
        System.out.println("Enter your name:");
        name = scanner.next();
        System.out.println("Enter your last name:");
        this.lastName = scanner.next();
        System.out.println("Enter your class level:");
        this.gradeYear = scanner.nextInt();

        setID();
        System.out.println(studentID);


    }


    public void setID() {
        id++;
        this.studentID = gradeYear + "" + id;
    }

    public void pick() {
        String course;
        do {


            System.out.println("Enter course to enroll  (Press 'X'  to quit)");
            course = scanner.next();
            if (!course.equals("X")) {
                courses += course;
                studentBills += costOfCourse;
                System.out.println("You just started: " + courses);
                System.out.println("Your current student bill is:" + studentBills);
            } else {
                break;
            }
        } while (1 != 2);

    }

    public void displayStudent() {
        System.out.print("First name:" + name + " Last name:" + lastName + " Class lv:" + gradeYear + "  StudentID: " + "\n");
        setID();
    }

    public void displayBalance() {
        System.out.println("Your balance is:" + studentBills);

    }

    public void tuitionPayment() {
        displayBalance();
        System.out.println("Tuition payment: ");
        int num = scanner.nextInt();
        studentBills -= num;
        displayBalance();
    }

    public void showInfo() {
        System.out.println("Name:" + name + " Last name:" + lastName + " StudentID:" + studentID + "\n"
                + "Your courses:" + courses + " Your balance is:" + studentBills);
    }


}